import React, { useEffect, useState } from 'react';
import Product from '../Product/Product';

const AllProducts = () => {


    const [products,setProducts]= useState([])
    
   useEffect(()=> {

  fetch('FakeData.json')
.then(res => res.json())
.then(data => setProducts(data))
   },[])

   const [cart,setCart]=useState([])
      const handleAddToCart = (product)=>{
const exist = cart.find(p => p.id === product.id)
if(exist){
alert(`(${product.Model})oi beta ek product koibar add koros`)
}
else{
  const newCart = [...cart,product]
  setCart(newCart)
}

      }
  
const handledeleteCart =(id)=>{
  const deletecart = cart.filter(p=> p.id !== id)
  setCart(deletecart)
}
    
    return (
  <div className="container">
          <div className='all_products'>
        <h1>All Products :{products.length}</h1>
        <div className="main">
  <div className="products_container">
 {
    products.map(product => <Product handleAddToCart={handleAddToCart} product= {product} key={product.id}></Product> )
 }


  </div>
  <div className="card_container">
    <div className="detals">
<h2>Cart{cart.length <=1? ' Prooduct' : ' Prooducts' } : {cart.length}</h2>
  {
cart.map(p=>
 <div>
<div className="main">
  <div className="img">
    <img src={p.img} alt="" />
  </div>
  <div className="text">
    <h3>{p.Model}</h3>
    <h3>{p.color}</h3>
    <h3>{p.Price } tk</h3>
  </div>
  <div className="button">
    <button onClick={()=> handledeleteCart(p.id)}>Delete</button>
  </div>
</div>
</div>
)
  
  }
   
    </div>

  </div>
        </div>
    </div>
  </div>
    );
};

export default AllProducts;