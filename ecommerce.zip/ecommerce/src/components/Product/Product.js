import React from 'react';

const Product = ({product,handleAddToCart}) => {
const {id,Model,color,Price,img} = product;

    return (
        <div className='item'>
       <img src={img} alt="" />
            <h2>Model:{Model}</h2>
            <h2>Color:{color}</h2>
            <h2>Price:{Price} tk</h2>
            <button onClick={ ()=> handleAddToCart(product)}>Add To Cart</button>
        </div>
    );
};

export default Product;