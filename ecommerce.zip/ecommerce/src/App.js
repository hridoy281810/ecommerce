import React from 'react';
import './App.css'
import AllProducts from './components/All Products/AllProducts';

const App = () => {


  return (
    <div>
  <AllProducts></AllProducts>
    </div>
  );
};

export default App;